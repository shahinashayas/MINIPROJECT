<!DOCTYPE html>
<html>
<head>
<script>
function validateForm() {
    var x = document.forms["myForm"]["fname"].value;
    if (x == "") {
        alert("Registeration completed");
        return false;
    }
}
</script>
<style>
body
{
<body background="regcustomer.jpg">
}


input[type=text],[type=date],[type=radio],[type=email],[type=password] ,select, textarea {
    width: 60%;
    padding: 12px;
    border: 2px solid #ccc;
    border-radius: 5px;
    resize: vertical;
}

h1
{
margin-left:120px;
color:white;
}
label {
    padding:12px,20px;
    display: inline-block;
color:white;
}

input[type=submit],[type=button] {
    
    background-color:green;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-left=200px;
    float: center;
}

input[type=submit]:hover {
    background-color: #45a049;
}
input[type=button]:hover {
    background-color: #45a049;
}
.container {
    border-radius:5px;
    background-image: url("regstaff.jpg");
    padding: 20px;
    margin-left:400px;
width:40%;
 
}

.col-25 {
    float: left;
    width: 25%;
    margin-top: 6px;
}

.col-75 {
    float: left;
    width: 75%;
    margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .col-25, .col-75, input[type=submit],input[type=button] {
        width: 100%;
        margin-top: 0;
    }
}
</style>
</head>
<body >


<div class="container">
<h1>Registration Form</h1>
 <form name="myForm" method="post" action="customerregister.php"  autocomplete="off"


   onsubmit="return validateForm()" method="post">
    <div class="row">
      <div class="col-25">
        <label for="fname">First Name</label>
      </div>
      <div class="col-75">
   <input type="text" name="firstname" id="firstname" pattern="[A-Z/a-z]{1,20}" required title="Enter only characters">
       
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="lname">Last Name</label>
      </div>
      <div class="col-75">
      <input type="text" name="lastname" id="lastname"  pattern="[A-Za-z]{1,20}" required title="Enter only characters">
       
      </div>
    <div class="row">
      <div class="col-25">
        <label for="address">Address</label>
      </div>
      <div class="col-75">
        <textarea  name="adress" id="adress" placeholder="Address.."required style="height:100px"></textarea>
      </div>
    </div>





  <div class="row">
      <div class="col-25">
        <label for="city">City</label>
      </div>
      <div class="col-75">
   <input type="text" name="city" id="city" pattern="[A-Z/a-z]{1,20}" required title="Enter only characters">
       
      </div>
    </div>

  <div class="row">
      <div class="col-25">
        <label for="lanmark">lanmark</label>
      </div>
      <div class="col-75">
   <input type="text" name="lanmark" id="lanmark" pattern="[A-Z/a-z]{1,20}[A-Z/a-z]{1,20}" required title="Enter only characters">
       
</div>
</div>



 <div class="row">
      <div class="col-25">
        <label for="housenumber">Housenumber</label>
      </div>
      <div class="col-75">
   <input type="text" name="houseno" id="houseno"  pattern=".{5,}[A-Z/a-z]"  placeholder="" checked required=" ">
      </div>
    </div>
 
<div class="col-15">
        <label for="address">Gender</label>
      </div>
<input type="radio" name="sex" id ="gen" checked="male">male  
  
 <input type="radio" name="sex" id ="gen" value="female">female</div>

<div class="row">
      <div class="col-25">
  <label for="dob">DOB</label>
      </div>
 <div class="col-75">
 <input type="date" name="DOB" id="DOB" placeholder="DOB.."required =" ">
</div>

 <div class="row">
      <div class="col-25">
        <label for="phn">phone number</label>
      </div>
      <div class="col-75">
       <input type="text" name="phnno" id="phnno" pattern="[7-9]{1}[0-9]{9}" required title="Phone number with 7-9 and remaing 9 digit with 0-9">
      
      </div>
<div class="row">
      <div class="col-25">
        <label for="email">Email</label>
      </div>
      <div class="col-75">
        <input type="email"  name="email" id="email" placeholder="Email id.." required>
      </div>
    </div>
<div class="row">
      <div class="col-25">
        <label for="dob">Password</label>
      </div>
      <div class="col-75">
 <input type="password" id="psw" name="password" id="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
       
      </div>

<div class="row">
      <div class="col-25">
        <label for="DISTRICT">Place</label>
      </div>
      <div class="col-75">
 
<table><tr><td><label for="DISTRICT"></td><td><select name="district" id="district">
<center><option>kanjirappally</option>
<option>pala</option>
<option>kodungoor</option>
<option>ponkunnam</option>
<option>mundakkayam</option>
<option>erumeli</option>
<option>manimala</option>
<option>changanacherry</option>
<option>Pampady</option>
<option>mukkada</option>
<option>kangazha</option>
<option>karukachal</option>
<option>nedumkunnam</option>
<option>paingana</option>
</center></table>

</td></tr>
<tr><td></td><td><input type="submit" name="submit" id="submit" value="submit"></td></tr>
</center></table>
<div class="row">
     <div class="col-25">
 
 
    
  
</div>

</body>
 </form>
<?php
 include "connection.php";
 if(isset($_POST['submit']))
{
$fn=$_POST['firstname'];
$ln=$_POST['lastname'];
$ad=$_POST['adress'];
$ci=$_POST['city'];
$la=$_POST['lanmark'];
$hn=$_POST['houseno'];
$ge=$_POST['gender'];
$DOB=$_POST['DOB'];
$ph=$_POST['phnno'];
$email=$_POST['email'];
$pas=md5($_POST['password']);
$di=$_POST['district'];






$sql="Insert into org1(email,password,status,role,logstatus) values('$email','$pas',0,'customer',1)";
$obj=new db();
$obj->execute($sql);
$sel="select loginid from org1 where email='$email' and password='$pas'";
$login=$obj->execute($sel);
//echo $login; error due to string
$strr=mysqli_fetch_array($login);
 //echo $strr[0];
//echo "success";
$lo=$strr[0];

//$pq="insert into customerregister(`firstname`,`lastname`,`adress`,`city`,`lanmark`,`houseno`,`gender`,`DOB`,`phnno`,`email`,`password`,`district`)values('$fn','$ln', '$ad','$ci','$la','$hn','$ge','$DOB','$ph','$email','$pas','district')";
$sqlll="Insert into customerregister(`firstname`,`lastname`,`adress`,`city`,`lanmark`,`houseno`,`gender`,`DOB`,`phnno`,`district`,loginid) values('$fn','$ln', '$ad','$ci','$la','$hn','$ge','$DOB','$ph','$di',$lo)";
$objj=new db();
$objj->execute($sqlll);
 echo "<script> alert('Success');
           window.location='ORG1.php'</script>";

}
 
  
  //echo "<script> ('Success');
          // window.location='Org1.php'</script>";

// header("location:ORG1.php");

?>


</body>
</html>
