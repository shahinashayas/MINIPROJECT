<html>
<head>
<style>
body {
  margin: 0;
  font-family: Times New Roman, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: right;
  color: #f2f2f2;
  text-align: center;
  padding: 8px 6px;
  text-decoration: none;
  font-size: 20px;
	
width:10%;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
h2 

  {
    color: tomato;
    text-align: center;
    
	margin-top:80px;
	margin-bottom:80px;

   }
h1{
	color:white;
}
.img{
	width:1800px;
	height:500px;
    }
.centered {
    position: absolute;
    top: 40%;
    left: 50%;
    transform: translate(-50%, -50%);
    }
.text{
	width:105%;
	height:50%;
	margin-left:200px;
	margin-top:100px;
	 column-count: 2;
      }
.footer {
  position:fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   height:8%;
   background-color: black;
   margin-top:100px;
}
ul{
margin:0px;
padding:0px;
list-style:none;
}
ul li{
float:left;
width:200px;
height:60px;
background-color:pink;
opacity:.9;
line-height:50px;
text-align:center;
font-size:20px;
margin-right:30px;
}
ul li a{
text-decoration:none;
}
ul li a:hover{
background-color-green;

}
ul li ul li
{
display:none;l
}
ul li:hover ul li{
display:block;
}
</style>
</head>
<body>

<ul>
 <li><a> BRANDS</a>
    <ul>
<li><a>NESTLE</a></li>
<li><a>NIRAPARA</a></li>
<li><a>EASTERN</a></li>
<li><a>KITCHEN TRESSURES</a></li>
<li><a>MERRYBOY</a></li>
<li><a>UNCLE JOHN</a></li>
<li><a>BRITANIYA</a></li>
<li><a>TROPICANO</a></li>
<li><a>MOMSMAGIC</a></li>
<li><a>GOODDAY</a></li>
</li></ul>


</ul>
<ul>
<li><a href="aboutus.html">ABOUT US</a></ul>
<ul><li><a href="contactas.html">CONTACT US</a></ul>
 
 


<ul><li><a>REGISTRATION</a>
<ul>

<li><a href="staffregister.php">staff here.....</a></li>

<li><a href="customerregister.php">customer here.....</a></li>

</li></ul>

</ul><ul><li><a href="ORG1.php">LOGIN</a></ul>
  </div>
</div>

<div class="centered"><h1><style="color:red;">ZELSONN</h1></div>



<div class="footer"></div>
<!-- Slide Show -->
<section>
  <img class="mySlides" src="primage1.jpg" style="width:100%">
  <img class="mySlides" src="primage2.jpg" style="width:100%">
  <img class="mySlides" src="primage3.jpg" style="width:100%">
<img class="mySlides" src="primage4.jpg" style="width:100%">
<img class="mySlides" src="primage5.jpg" style="width:100%">
<img class="mySlides" src="primage6.jpg" style="width:100%">
<img class="mySlides" src="home image sm.jpg" style="width:100%">


</section>

<script>
// Automatic Slideshow - change image every 3 seconds
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}
  x[myIndex-1].style.display = "block";
  setTimeout(carousel, 2000);
}
</script>
</body>
</html>