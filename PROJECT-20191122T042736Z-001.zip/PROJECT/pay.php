
<?php

include("connection.php");
session_start();
$cid=$_SESSION['lid'];

$amount=$_SESSION['amount'];
 
$obj=new db();
$select="select * from customerregister WHERE loginid=$cid";
$data=$obj->execute($select);

//$row=mysqli_fetch_array($data);
if(mysqli_num_rows($data)>0)
{

while($row=mysqli_fetch_array($data))
{	
$firstname=$row['firstname'];
$lastname=$row['lastname'];

?>


<!DOCTYPE html>
<html>
<head>
<script>
function validateForm() {
    var x = document.forms["myForm"]["fname"].value;
    if (x == "") {
        alert("Registeration completed");
        return false;
    }
}
</script>
<style>
body
{
<body background="EYEIMG.jpg">
}


input[type=text],[type=date],[type=button],[type=email],[type=password] ,select, textarea {
    width: 60%;
    padding: 12px;
    border: 2px solid #ccc;
    border-radius: 5px;
    resize: vertical;
}

h1
{
margin-left:120px;
color:white;
}
label {
    padding:12px,20px;
    display: inline-block;
color:white;
}

input[type=submit],[type=button] {
    
    background-color:green;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-left=200px;
    float: center;
}

input[type=submit]:hover {
    background-color: #45a049;
}
input[type=button]:hover {
    background-color: #45a049;
}
.container {
    border-radius:5px;
    background-image: url("regstaff.jpg");
    padding: 180px;
    margin-left:300px;
width:40%;
 
}

.col-25 {
    float: left;
    width: 25%;
    margin-top: 6px;
}

.col-75 {
    float: left;
    width: 75%;
    margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .col-25, .col-75, input[type=submit],input[type=button] {
        width: 100%;
        margin-top: 0;
    }
}
</style>
</head>
<body >


<div class="container">
<h1>PAYNOW</h1>
<fieldset>
 <form name="myForm" action="total.php" autocomplete="off"

   onsubmit="return validateForm()" method="post">

<div class="column">
    
	
	
	<h3><?php echo $firstname;?><br>  </h3>
	<h3><?php echo $lastname;?><br>  </h3>

       
    <div class="row">
     

<div class="row">
      <div class="col-25">
        <label for="TOTL">quantity:</label>
      </div>
      <div class="col-75">
        <input type="text"  name="quantity" id="quantity"  required="">
      </div>
	  <div class="row">
      <div class="col-25">
        <label for="TOTL">amount:</label>
      </div>
      <div class="col-75">
        <input type="text"  name="amount"  value="<?php echo $amount;?>" required="">
      </div>
<div class="row">
     <div class="col-25">
    <center><input type="submit" id="total" name="total value="total"> </center> 
 </div>


 <div class="row">
     <div class="col-25">
    <center><button type="submit">CONFIRM</button> </center> 
 </div>
 <div class="col-75">


  </div>


 <?php
 }
 

}
?>

</fieldset>
</body>
</form>



<html>