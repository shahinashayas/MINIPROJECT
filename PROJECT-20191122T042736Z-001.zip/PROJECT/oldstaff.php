<?php

include("connection.php");
session_start();
 
$obj=new db();
$select="select * from staffregister";
$data=$obj->execute($select);
if(mysqli_num_rows($data)>0)
{

while($row=mysqli_fetch_array($data))
{	
$firstname=$row['firstname'];
$lastname=$row['lastname'];
$adress=$row['adress'] ;
$sex=$row['sex'] ;
$DOB=$row['DOB'] ;




?>



<!DOCTYPE html>
<html>
<head>
<style>


* {
  box-sizing: border-box;
}

.column {
  float: left;
  width: 33.33%;
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}
</style>
</head>
<body>

<div class="container">

 <form name="myForm" method="post" action="oldstaff.php"


 onsubmit="return validateForm()" method="post">
   
     
       
    <div class="column">
    <img src="staffimage.jpg" alt="Snow" style="width:50%">
	
      
	<h3><?php echo $firstname;?>  <?php echo $lastname;?></h3>
 </h3> 
       <h3> <?php echo $adress;?> </h3>
<h3> <?php echo $sex;?> </h3>
<h3> <?php echo $DOB;?> </h3>

	 

 
 
  </div>
<?php
 }
 
}

?>




 
 </body>

</html>
