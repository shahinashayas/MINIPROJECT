



<?php
session_start();

session_unset();
session_destroy();
header("location:HOME1.php");
exit();
?>