<!DOCTYPE html>
<html>
<head>

<style>
body
{
<body background="regcustomer.jpg">
}


input[type=text],[type=date],[type=radio],[type=email],[type=password] ,select, textarea {
    width: 60%;
    padding: 12px;
    border: 2px solid #ccc;
    border-radius: 5px;
    resize: vertical;
}

h1
{
margin-left:120px;
color:white;
}
label {
    padding:12px,20px;
    display: inline-block;
color:white;
}

input[type=submit],[type=button] {
    
    background-color:green;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-left=200px;
    float: center;
}

input[type=submit]:hover {
    background-color: #45a049;
}
input[type=button]:hover {
    background-color: #45a049;
}
.container {
    border-radius:5px;
    background-image: url("regstaff.jpg");
    padding: 20px;
    margin-left:400px;
width:40%;
 
}

.col-25 {
    float: left;
    width: 25%;
    margin-top: 6px;
}

.col-75 {
    float: left;
    width: 75%;
    margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .col-25, .col-75, input[type=submit],input[type=button] {
        width: 100%;
        margin-top: 0;
    }
}
</style>
<script language="javascript">
function abc()
{
if(document.form1.firstname.value==""||document.form1.lastname.value==""||document.form1.adress.value==""||document.form1.city.value==""||document.form1.lanmark.value==""||document.form1.houseno.value==""||document.form1.sex.value==""||document.form1.DOB.value==""||document.form1.phonno.value==""||document.form1.email.value==""||document.form1.password.value==""||document.form1.district.value=="")
{
alert("enter the details");
return(false);
}
if((document.form1.firstname.value)==true)
{
alert("Enter name");
return(false);
}

if((document.form1.lastname.value)==true)
{
alert("Enter name");
return(false);
}
if((document.form1.adress.value)==true)
{
alert("Enter address");
return(false);
}
if((document.form1.city.value)==true)
{
alert("Enter city");
return(false);
}
if((document.form1.lanmark.value)==true)
{
alert("Enter lanmark");
return(false);
}
if((document.form1.houseno.value)==true)
{
alert("Enter lanmark");
return(false);
}
if((document.form1.gender.value)==true)
{
alert("Enter gender");
return(false);
}
if((document.form1.DOB.value)==true)
{
alert("Enter DOB");
return(false);
}

if(isNaN(document.form1.phnno.value)==true)
{
alert("Phone should be numeric");
return(false);
}
if(document.form1.no.value.length<10)
{
alert("Phone should be min 10 digit");
return(false);
}


if(document.form1.email.value.indexOf("@")==-1 || document.form1.email.value.indexOf(".")==-1 || document.form1.email.value.indexOf(",")!=-1 || document.form1.email.value.indexOf(" ")!=-1)
{
alert("Invalid email");
return (false);
}

if((document.form1.password.value)==true)
{
alert("Enter password");
return(false);
}

if((document.form1.district.value)==true)
{
alert("Enter your district");
return(false);
}
 
}
</script>
</head>
<body >


<div class="container">
<h1>Registration Form</h1>
 <form name="form1"  action="customerregister.php"


   onsubmit="return abc()" method="post">
    <div class="row">
      <div class="col-25">
        <label for="fname">First Name</label>
      </div>
      <div class="col-75">
   <input type="text" name="firstname" id="firstname">
       
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="lname">Last Name</label>
      </div>
      <div class="col-75">
      <input type="text" name="lastname" id="lastname">
       
      </div>
    <div class="row">
      <div class="col-25">
        <label for="address">Address</label>
      </div>
      <div class="col-75">
        <textarea  name="adress" id="adress" placeholder="Address.."></textarea>
      </div>
    </div>





  <div class="row">
      <div class="col-25">
        <label for="city">City</label>
      </div>
      <div class="col-75">
   <input type="text" name="city" id="city">
       
      </div>
    </div>

  <div class="row">
      <div class="col-25">
        <label for="lanmark">lanmark</label>
      </div>
      <div class="col-75">
   <input type="text" name="lanmark" id="lanmark">
       
</div>
</div>



 <div class="row">
      <div class="col-25">
        <label for="housenumber">Housenumber</label>
      </div>
      <div class="col-75">
   <input type="text" name="houseno" id="houseno">
      </div>
    </div>
 
<div class="col-15">
        <label for="address">Gender</label>
      </div>
<input type="radio" name="sex" id ="gen" value="male">male
  
 <input type="radio" name="sex" id ="gen" value="female">female</div>

<div class="row">
      <div class="col-25">
  <label for="dob">DOB</label>
      </div>
 <div class="col-75">
 <input type="date" name="DOB" id="DOB" placeholder="DOB..">
</div>
</div>

<div class="row">
      <div class="col-25">
        <label for="lname">phone number</label>
      </div>
      <div class="col-75">
      <input type="text" name="phnno" id="lastname">
       
      </div>
	  </div>

<div class="row">
      <div class="col-25">
        <label for="email">Email</label>
      </div>
      <div class="col-75">
        <input type="email"  name="email" id="email" placeholder="Email id..">
      </div>
    </div>
<div class="row">
      <div class="col-25">
        <label for="dob">Password</label>
      </div>
      <div class="col-75">
 <input type="password" id="psw" name="password" id="password">
       
      </div>

<div class="row">
      <div class="col-25">
        <label for="DISTRICT">District</label>
      </div>
      <div class="col-75">
 
<table><tr><td><label for="DISTRICT"></td><td><select name="district" id="district">
<center><option>Tvm</option>
<option>Kollam</option>
<option>Pta</option>
<option>Alappuzha</option>
<option>Kottayam</option>
<option>Ekm</option>
<option>Idukki</option>
<option>Thrissur</option>
<option>Palakkad</option>
<option>Kozhikodu</option>
<option>Malappuram</option>
<option>Kannur</option>
<option>Wayanadu</option>
<option>Kazargodu</option>
</center></table>

</td></tr>
<tr><td></td><td><input type="submit" name="submit" id="submit" value="submit"></td></tr>
</center></table>
<div class="row">
     <div class="col-25">
 
 
    
  
</div>


 </form>
<?php
 include "connection.php";
 if(isset($_POST['submit']))
{
$fn=$_POST['firstname'];
$ln=$_POST['lastname'];
$ad=$_POST['adress'];
$ci=$_POST['city'];
$la=$_POST['lanmark'];
$hn=$_POST['houseno'];
$ge=$_POST['sex'];
$DOB=$_POST['DOB'];
$ph=$_POST['phnno'];
$email=$_POST['email'];
$pas=$_POST['password'];
$di=$_POST['district'];






$sql="Insert into org1(email,password,status,role) values('$email','$pas',0,'customer')";
$obj=new db();
$obj->execute($sql);
$sel="select loginid from org1 where email='$email' and password='$pas'";
$login=$obj->execute($sel);

$strr=mysqli_fetch_array($login);
 
$lo=$strr[0];

$sqlll="Insert into customerregister(`firstname`,`lastname`,`adress`,`city`,`lanmark`,`houseno`,`sex`,`DOB`,`phnno`,`district`,loginid) values('$fn','$ln', '$ad','$ci','$la','$hn','$ge','$DOB','$ph','$di',$lo)";
$objj=new db();
$objj->execute($sqlll);
 echo "<script> alert('success');
 
           window.location='ORG1.php'</script>";

}
  ?>
</body>
</html>
