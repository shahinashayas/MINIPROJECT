<!DOCTYPE html>
<html>
<head>
<script>
function validateForm() {
    var x = document.forms["myForm"]["fname"].value;
    if (x == "") {
        alert("Registeration completed");
        return false;
    }
}
</script>
<style>
body
{
<body background="regcustomer.jpg">
}


input[type=text],[type=date],[type=radio],[type=email],[type=password] ,select, textarea {
    width: 60%;
    padding: 12px;
    border: 2px solid #ccc;
    border-radius: 5px;
    resize: vertical;
}

h1
{
margin-left:120px;
color:white;
}
label {
    padding:12px,20px;
    display: inline-block;
color:white;
}

input[type=submit],[type=button] {
    
    background-color:green;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-left=200px;
    float: center;
}

input[type=submit]:hover {
    background-color: #45a049;
}
input[type=button]:hover {
    background-color: #45a049;
}
.container {
    border-radius:5px;
    background-image: url("regstaff.jpg");
    padding: 20px;
    margin-left:400px;
width:40%;
 
}

.col-25 {
    float: left;
    width: 25%;
    margin-top: 6px;
}

.col-75 {
    float: left;
    width: 75%;
    margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .col-25, .col-75, input[type=submit],input[type=button] {
        width: 100%;
        margin-top: 0;
    }
}
</style>
</head>
<body >

<div class="container">
<h1>Registration Form</h1>
 
<form name="myForm" method="post" action="item.php"


   onsubmit="return validateForm()" method="post">



  <input type="file" name="image"  id="image"accept="image/*">
 

 


  
    <div class="row">
      <div class="col-25">
        <label for="itemname">Itemname:</label>
      </div>
      <div class="col-75">
   <input type="text" name="itemname"  required title="">
       
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="quantity">Quantity</label>
      </div>
      <div class="col-75">
      <input type="text" name="quantity"   required title="">
       
      </div>
</div>

<div class="row">
      <div class="col-25">
        <label for="amount">Amount</label>
      </div>
      <div class="col-75">
      <input type="text" name="amount"   required title="">
       
      </div>
</div>
<div class="row">
      <div class="col-25">
        <label for="brand">Brand</label>
      </div>
      <div class="col-75">
      <input type="text" name="brand"   required title="">
       
      </div>
</div>
 <div class="row">
      <div class="col-25">
        <label for="barcode">Barcode</label>
      </div>
      <div class="col-75">
      <input type="text" name="barcode"   required title="">
       
      </div>
</div>
<div class="row">
      <div class="col-25">
        <label for="discount">Discount</label>
      </div>
      <div class="col-75">
      <input type="text" name="discount"   required title="">
       
      </div>
</div>
<div class="row">
      <div class="col-25">
        <label for="discount">Discription</label>
      </div>
      <div class="col-75">
 <textarea  name="description" id="description" placeholder="description.."required style="height:100px"></textarea>
    
       
      </div>
</div>















      

<input type="submit" name="submit" id="submit" value="submit">
  
</div>
</body>
 </form>

<?php
 include "connection.php";
 if(isset($_POST['submit']))
{
$im=$_POST['image'];
$in=$_POST['itemname'];
$qn=$_POST['quantity'];
$am=$_POST['amount'];
$br=$_POST['brand'];
$ba=$_POST['barcode'];
$dis=$_POST['discount'];
$des=$_POST['description'];




$sqlll="Insert into item(`image`,`itemname`,`quantity`,`amount`,`brand`,`barcode`,`discount`,`description`)values('$im','$in', '$qn','$am','$br','$ba','$dis','$des')";
$objj=new db();
$objj->execute($sqlll);
 echo "<script> alert('item added successfully');
           window.location='adminlogin.php'</script>";

}
 
  
 

?>



</body>
</html>
