<?php 
//session_start(); 
//echo "popo";

include("connection.php");
if(isset($_POST['submit']))
{
    $email =$_POST['email'];
	$pas =$_POST['password'];
//echo $u_pass;

$sql="select * from org1 where email='$email'";
//echo $sql;

$result=mysqli_query($con,$sql);
$rowcount=mysqli_num_rows($result);
if($rowcount!=0)
{

	while($row=mysqli_fetch_array($result))
	{
		$emaill=$row['email'];
		$pass=$row['password'];
		$dbu_role=$row['role'];

        
		if($emaill==$email && $pass==$pas)
		{
			//$_SESSION['email']=$email;
                       //$_SESSION['password']=$pas;
		     //echo $dbu_type;
			if($dbu_role=='admin')	
			{
				//$_SESSION['usertype']="customer";
               	header('Location:inlogin.php');
			}
			else if($dbu_type==1)
			{
				//$_SESSION['usertype']="staff";
                	header('Location: userindex.html');
			}
			else if($dbu_type==2)
			{
				//$_SESSION['usertype']="User";
					//header("location:../important/User/user_home.php");
			}
		}
		else
        {
				//header("location:signin.php?error=wrong password");
          //echo "wrong";
        }
	}
}
else
{
			//header("location:signin.php?error=User Not Found");
			//echo "not found";	
}
}
?>