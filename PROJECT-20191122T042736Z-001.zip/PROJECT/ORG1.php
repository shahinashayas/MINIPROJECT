
<!DOCTYPE html>
<html>
<head>
<script>
function validateForm() {
    var x = document.forms["myForm"]["fname"].value;
    if (x == "") {
        alert("Registeration completed");
        return false;
    }
}
</script>
<style>
body
{
<body background="contact.jpg">
}


input[type=text],[type=date],[type=button],[type=email],[type=password] ,select, textarea {
    width: 60%;
    padding: 12px;
    border: 2px solid #ccc;
    border-radius: 5px;
    resize: vertical;
}

h1
{
margin-left:120px;
color:white;
}
label {
    padding:12px,20px;
    display: inline-block;
color:white;
}

input[type=submit],[type=button] {
    
    background-color:green;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-left=200px;
    float: center;
}

input[type=submit]:hover {
    background-color: #45a049;
}
input[type=button]:hover {
    background-color: #45a049;
}
.container {
    border-radius:5px;
    background-image: url("contact.jpg");
    padding: 180px;
    margin-left:300px;
width:40%;
 
}

.col-25 {
    float: left;
    width: 25%;
    margin-top: 6px;
}

.col-75 {
    float: left;
    width: 75%;
    margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .col-25, .col-75, input[type=submit],input[type=button] {
        width: 100%;
        margin-top: 0;
    }
}
</style>
</head>
<body >

<div class="container">
 <form name="myForm"  method="post" action="ORG1.php" autocomplete="off"

 
   onsubmit="return validateForm()" method="post">
    <div class="row">
      <div class="col-25">
        <label for="entername">Email:</label>
      </div>
      <div class="col-75">
       <input type="email"  name="email" id="email" placeholder="Email id.." required>
        
      </div>
    </div>
    
<div class="row">
      <div class="col-25">
        <label for="dob">PASSWORD:</label>
      </div>
      <div class="col-75">
 <input type="password" id="password" name="password"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
       
      </div>
 <div class="row">
     <div class="col-25">
  <button type="submit" name="submit" id="submit">LOGIN</button> </br>
  

 </div>
 
 


</body>
</form>
<?php 

           

include("connection.php");
session_start();
 if(isset($_POST['submit']))
 {
	$email=$_POST['email'];

	$pas=md5($_POST['password']);
       
	
	$obj=new db();
	$select="select * from org1 where email='$email' and password='$pas'";
	
	$data=$obj->execute($select);
	if(mysqli_num_rows($data)>0)
	{
		while($row=mysqli_fetch_array($data))
		{
		
			if($row['role']=='admin')
			{
				$_SESSION['lid']=$row['loginid'];
				$_SESSION['role']=$row['role'];
				header("location:adminlogin.php");
			}
			if($row['role']=='customer')
			{
				$_SESSION['lid']=$row['loginid'];
				$_SESSION['role']=$row['role'];
				header("location:inlogin.php");
			}
                       
                      if($row['role']=='staff')
                       {
                    if ($row['logstatus']=='0')
                       {
                    ?>
					<script> 
					alert("u are not approved");

            </script>
			<?php
			
		


                      }
                   
   else
{
                 $_SESSION['lid']=$row['loginid'];
				$_SESSION['role']=$row['role'];
				header("location:staffhome/generic.php");
}
		}
		}
	}
	
	else
	{
		?>
		<script>
		alert("check username and password");
		window.location="org1.php";
		</script>
		<?php
		//echo "err";
		
	

	}
 }
 
 
 
 ?>