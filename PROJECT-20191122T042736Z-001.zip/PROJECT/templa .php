<!DOCTYPE html>
<html>
<head>
<script>
function validateForm() {
    var x = document.forms["myForm"]["fname"].value;
    if (x == "") {
        alert("Registeration completed");
        return false;
    }
}
</script>
<style>



}

body {
  margin: 0;
  padding: 0;
  background: #DDD;
  font-size: 16px;
  color: #222;
  font-family: 'Roboto', sans-serif;
  font-weight: 300;
}

#login-box {
  position: relative;
  margin: 5% auto;
  width: 600px;
  height: 700px;
  background: #FFF;
  border-radius: 2px;
 background-image: url("regcustomer.jpg");
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
}

.left {
  position: absolute;
  top: 0;
  left: 0;
  box-sizing: border-box;
  padding: 40px;
  width: 300px;
  height: 400px;
}

h1 {
  margin: 0 0 20px 0;
  font-weight: 300;
  font-size: 28px;
}

input[type="text"],
input[type="password"] {
  display: block;
  box-sizing: border-box;
  margin-bottom: 20px;
  padding: 4px;
  width: 220px;
  height: 32px;
  border: none;
  border-bottom: 1px solid #AAA;
  font-family: 'Roboto', sans-serif;
  font-weight: 400;
  font-size: 15px;
  transition: 0.2s ease;
}

input[type="text"]:focus,
input[type="password"]:focus {
  border-bottom: 2px solid #16a085;
  color: #16a085;
  transition: 0.2s ease;
}

input[type="submit"] {
  margin-top: 28px;
  width: 120px;
  height: 32px;
  background: #16a085;
  border: none;
  border-radius: 2px;
  color: #FFF;
  font-family: 'Roboto', sans-serif;
  font-weight: 500;
  text-transform: uppercase;
  transition: 0.1s ease;
  cursor: pointer;
}

input[type="submit"]:hover,
input[type="submit"]:focus {
  opacity: 0.8;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
  transition: 0.1s ease;
}

input[type="submit"]:active {
  opacity: 1;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
  transition: 0.1s ease;
}

.or {
  position: absolute;
  top: 180px;
  left: 280px;
  width: 40px;
  height: 40px;
  background: #DDD;
  border-radius: 50%;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
  line-height: 40px;
  text-align: center;
}

.right {
  position: absolute;
  top: 0;
  right: 0;
  box-sizing: border-box;
  padding: 40px;
  width: 300px;
  height: 400px;
  
 background-image: url("regcustomer.jpg");
  background-size: cover;
  background-position: center;
  border-radius: 0 2px 2px 0;
}

.right .loginwith {
  display: block;
  margin-bottom: 40px;
  font-size: 28px;
  color: #FFF;
  text-align: center;
}

button.social-signin {
  margin-bottom: 20px;
  width: 220px;
  height: 36px;
  border: none;
  border-radius: 2px;
  color: #FFF;
  font-family: 'Roboto', sans-serif;
  font-weight: 500;
  transition: 0.2s ease;
  cursor: pointer;
}

button.social-signin:hover,
button.social-signin:focus {
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
  transition: 0.2s ease;
}

button.social-signin:active {
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
  transition: 0.2s ease;
}

button.social-signin.facebook {
  background: #32508E;
}

button.social-signin.twitter {
  background: #55ACEE;
}

button.social-signin.google {
  background: #DD4B39;
}
</style>
</head>
<body >
<div class="container">
 <form name="myForm"  method="post" action="ORG1.html"

 
   onsubmit="return validateForm()" method="post">
<div id="login-box">
  <div class="left">
    <h1>STAFF REGISTRATION</h1>

    <input type="text" name="firstname" pattern="[A-Z/a-z]{1,20}" required title="Enter only characters"placeholder="Firstname" />


    <input type="text" name="lastname"  pattern="[A-Z/a-z]{1,20}" required title="Enter only characters"placeholder="Lastname" />

         <textarea  name="adress" placeholder="Address.."required style="height:100px"></textarea /><br>

<input type="radio" name="sex" id ="gen" value="male">male
 <input type="radio" name="sex" id ="gen" value="female">female</br>
<br><br>

 <input type="date" name="DOB" placeholder="DOB".."required/>
<br><br>

 <input type="text" name="adharno" placeholder="Adharnumber" pattern=".{12,12}" required title="enter 12 digit number in your adhar card" />
 
 <input type="text" name="phnno" placeholder="phone number" pattern="[7-9]{1}[0-9]{9}" required title="Phone number with 7-9 and remaing 9 digit with 0-9" />
    

  <input type="email"  name="email" id="email" placeholder="Email id.." required />
<br>
<br>
    <input type="password" name="password" placeholder="Password"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required />
    
    
    <input type="submit" name="signup_submit" value="Sign me up" />
  </div>
  
  
</body>
</form>
<?php
 include "connection.php";
 if(isset($_POST['submit']))
{
$fn=$_POST['firstname'];
$ln=$_POST['lastname'];
$ad=$_POST['adress'];
$ge=$_POST['sex'];
$DOB=$_POST['DOB'];
$an=$_POST['adharno'];
$pn=$_POST['Phnno'];
$email=$_POST['email'];
$pas=$_POST['password'];

$sql="Insert into org1(email,password,status,role) values('$email','$pas',1,'staff')";
$obj=new db();
$obj->execute($sql);
$sel="select loginid from org1 where email='$email' and password='$pas'";
$login=$obj->execute($sel);
//echo $login; error due to string
$strr=mysqli_fetch_array($login);
 //echo $strr[0];
//echo "success";
$lo=$strr[0];

$sqlll="Insert into staffregister(`firstname`,`lastname`,`adress`,`sex`,`DOB`,`adharno`,`phnno`,loginid)values('$fn','$ln', '$ad' , '$ge', '$DOB' ,'$an', '$pn',$lo)";
$objj=new db();
$objj->execute($sqlll);
 echo "<script> alert('Success');
           window.location='ORG1.php'</script>";

}
 
  
  //echo "<script> ('Success');
          // window.location='Org1.php'</script>";

// header("location:ORG1.php");

?>


</body>
</html>



