
<?php

include("connection.php");
session_start();
 
$obj=new db();
$select="select * from item";
$data=$obj->execute($select);

//$row=mysqli_fetch_array($data);
if(mysqli_num_rows($data)>0)
{
$x=0;
while($row=mysqli_fetch_array($data))
{	
$itemimage=$row['image'];
$itemname=$row['itemname'];
$quantity=$row['quantity'] ;
$amount=$row['amount'] ;
$des=$row['description'] ;





//all other values should given like this here
?>



<!DOCTYPE html>
<html>
<head>
<style>


* {
  box-sizing: border-box;
}

.column {
  float: left;
  width: 33.33%;
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}
</style>
</head>
<body>

<div class="container">

 <form name="myForm" method="post" action="pay.php"


   onsubmit="return validateForm()" method="post">
    <div class="row">


  
  <!-- <div class="column">
    
<h3><?php echo $itemimage;?>Baby cream <br></h3>
<h3 <?php echo $itemname;?>100 gm <br></h3>
<h3  ><?php echo $quantity;?> </h3> <br>
<h3  > <?php echo $amount;?></h3> <td>




<h3 <?php echo "$amount";?>Rs/-60 </h3> <td>
<button type="submit"><a href="largeimage.html">View details </a></button> </td>
  </div>

-->




<div class="column">
    <img src="himalaya2.jpg" alt="Snow" style="width:50%">
	
	
	<h3><?php echo $itemimage;?><br>  </h3>
	<h3><?php echo $itemname;?><br>  </h3>

<h3  ><?php echo $quantity;?> </h3> <br>
<h3  > <?php echo $amount;
//$_SESSION['amount']=$row['amount'];
$x=$x+1;
?></h3> <td>


 
  <button type="submit">BUY NOW <a href="PAYNOW1.php"> </a></button> </td>
  </div>
  <!--
  
  <div class="column">
    <img src="himalaya1.jpg" alt="Snow" style="width:50%">
<h3 <?php /*echo "$itemname";?>Babycream <br>
<h3 <?php echo "$quantity";?>30 gm<br> 
<h3 <?php echo "$amount";?>Rs/-40</h3> <td>
<button type="submit">view details</button> </td>
  </div>
<div class="column">
    <img src="himalaya.jpg" alt="Snow" style="width:40%">
<h3 <?php echo "$itemname";?>Bath <br>
 <h3 <?php echo "$quantity";?>30 gm<br> 
<h3 <?php echo "$amount";?>Rs/-20</h3><td>
<button type="submit">view details</button> </td> 
  </div>
<div class="column">
    <img src="himalaya.jpg" alt="Snow" style="width:40%">
<h3 <?php echo "$itemname";?>Babycream <br>
<h3 <?php echo "$quantity";?>30 gm<br><h3 <?php echo "$amount";?>Rs/-40</h3> <td>
<button type="submit">view details</button> </td>
  </div>
  <div class="column">
    <img src="himalaya.jpg" alt="Snow" style="width:40%">
<h3 <?php echo "$itemname";?>Babycream <br>
<h3 <?php echo "$quantity";?>30 gm<br><h3 <?php echo "$amount";  

*/
?>Rs/-40</h3> <td>
<button type="submit">view details</button> </td>
  </div>
 
 
 -->
<?php
 }
 
}
$_SESSION['amount']=$x;
?>







 
 </body>

</html>
