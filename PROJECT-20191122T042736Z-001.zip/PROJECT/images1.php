<!DOCTYPE html>
<html>
<head>
<style>
* {
  box-sizing: border-box;
}

.column {
  float: left;
  width: 33.33%;
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}
</style>
</head>
<body>

<div class="container">

 <form name="myForm" method="post" action="largeimage.php"


   onsubmit="return validateForm()" method="post">
<div class="topnav">
  

<a href="inlogin.php"> BACK</a></ul><br>
<center><a href="Home1.php">HOME</a></center></ul>
</div>
    <div class="row">


  
<div class="column">
     <img src="i2.jpg" alt="snow" style="width:25%">
<h3>himalaya <br>
<h3>100 gm <br><h3>Rs/-60</h3> <td>
<button type="submit"><a href="pay.php">View details </a></button> </td>
  </div>






<div class="column">
    <img src="i2.jpg" alt="snow" style="width:25%">
<h3>sebamade <br>
<h3>100 gm <br><h3>Rs/-60</h3> <td>
<button type="submit">View details <a href="pay.php"> </a></button> </td>
  </div>
<div class="column">
    <img src="i3.jpg" alt="snow" style="width:25%">
<h3>jhons <br>
<h3>30 gm<br><h3>Rs/-40</h3> <td>
<button type="submit">view details</button> </td>
  </div>
<div class="column">
    <img src="i4.jpg" alt="snow" style="width:25%">
<h3>powder <br>
<h3>Rs/-20</h3> 
  </div>
<div class="column">
   <img src="i5.jpg" alt="snow" style="width:25%">
<h3>pigeon<br>
<h3>30 gm<br><h3>Rs/-40</h3> <td>
<button type="submit">view details</button> </td>
  </div>
  <div class="column">
   <img src="i6.jpg" alt="snow" style="width:25%">
<h3>Babyoil <br>
<h3>30 gm<br><h3>Rs/-40</h3> <td>
<button type="submit">view details</button> </td>
  </div>
<div class="column">
   <img src="i7.jpg" alt="snow" style="width:25%">
<h3>mustedil <br>
<h3>30 gm<br><h3>Rs/-40</h3> <td>
<button type="submit">view details</button> </td>
  </div>
<div class="column">
   <img src="i8.jpg" alt="snow" style="width:25%">
<h3>Baby soap <br>
<h3>30 gm<br><h3>Rs/-40</h3> <td>
<button type="submit">view details</button> </td>
  </div>


  <div class="column">
    <img src="img_mountains.jpg" alt="Mountains" style="width:100%">
  </div>
</div>

</body>
</html>
