<?php

include("connection.php");
session_start();
$bcid=$_SESSION['lid'];

//$amount=$_SESSION['amount'];
 
$obj=new db();
$select="select * from staffregister WHERE loginid=$bcid";
$data=$obj->execute($select);

//$row=mysqli_fetch_array($data);
if(mysqli_num_rows($data)>0)
{

while($row=mysqli_fetch_array($data))
{	
$firstname=$row['firstname'];
$lastname=$row['lastname'];
$adress=$row['adress'];

$DOB=$row['DOB'];


?>



<style>

.container {
    border-radius:5px;
    background-image: url("regstaff.jpg");
    padding: 180px;
    margin-left:300px;
width:40%;
 
}


</style>
</head>
<body >


<div class="container">

<fieldset>
 <form name="myForm" action="total.php" autocomplete="off"

   onsubmit="return validateForm()" method="post">

<div class="column">
    
	
	<div class="column">
    <img src="himalaya2.jpg" alt="Snow" style="width:50%">
	<h3><?php echo $firstname;?><br>  </h3>
	<h3><?php echo $lastname;?><br>  </h3>
	<h3><?php echo $adress;?><br>  </h3>
	<h3><?php echo $DOB;?><br>  </h3>

       
    
     

	  

</div>
 


  </div>


 <?php
 }
 

}
?>

</fieldset>
</body>
</form>



<html>