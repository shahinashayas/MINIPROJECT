<!DOCTYPE html>
<html>
<head>
<script>
function myfunction()
{
var x=document.forms["myForm"]["firstname"].value;
if(x=="")
{
alert("Please Fill name Field");
document.getElementById('firstname').focus();
return false;
}
 
 if ((x.length < 3) || (x.length > 30))
  {
    alert("Your Character must be 3 to 15 Character");
    document.getElementById('firstname').focus();
     return false;
   }

  
    var pattern1 = new RegExp("^[a-zA-Z ]*$"); 
      if(!pattern1.test(document.myForm.firstname.value)) 
	  {
      alert("Error: Please enter valid name!");
      myform.cust_name.focus();
    return false;
     }
var x=document.forms["myForm"]["lasttname"].value;
if(x=="")
{
alert("Please Fill name Field");
document.getElementById('lastname').focus();
return false;
}
 
 if ((x.length < 3) || (x.length > 30))
  {
    alert("Your Character must be 3 to 15 Character");
    document.getElementById('lastname').focus();
     return false;
   }

  
    var pattern1 = new RegExp("^[a-zA-Z ]*$"); 
      if(!pattern1.test(document.myForm.lastname.value)) 
	  {
      alert("Error: Please enter valid name!");
      myform.lastname.focus();
    return false;
     }





var a=document.forms["myForm"]["adress"].value;
if(a=="")
{
alert("Please Fill Address Field");
document.getElementById('adress').focus();
return false;
}
var a=document.forms["myForm"]["city"].value;
if(a=="")
{
alert("Please Fill city Field");
document.getElementById('city').focus();
return false;
}
var a=document.forms["myForm"]["lanmark"].value;
if(a=="")
{
alert("Please Fill city Field");
document.getElementById('lanmark').focus();
return false;
}
if( document.myform.houseno.value == "" ||
           isNaN( document.myForm.houseno.value) ||
           document.myForm.houseno.value.length != 10 )
   {
     alert( "Please provide a valid Mob upto 10 digit" );
   document.getElementById('houseno').focus();
     return false;
   }
   var pattern = new RegExp("^([6-9]{1})([0-9]{9})$"); 
      if(!pattern.test(document.myForm.houseno.value)) 
	  {
      alert("Error: Phone Number is invalid!");
      myForm.houseno.focus();
    return false;
     }



if( document.myForm.phnno.value == "" ||
           isNaN( document.myForm.phnno.value) ||
           document.myForm.phnno.value.length != 10 )
   {
     alert( "Please provide a valid Mobile Number upto 10 digit" );
   document.getElementById('phnno').focus();
     return false;
   }
   var pattern = new RegExp("^([6-9]{1})([0-9]{9})$"); 
      if(!pattern.test(document.myForm.phnno.value)) 
	  {
      alert("Error: Phone Number is invalid!");
      myForm.phnno.focus();
    return false;
     }
var e=document.forms["myForm"]["email"].value;
if(e=="")
{
alert("Please Fill emailid Field");
document.getElementById('email').focus();
return false;
}
var email = document.myForm.email.value;
  atpos = email.indexOf("@");
  dotpos = email.lastIndexOf(".");
  if (email == "" || atpos < 1 || ( dotpos - atpos < 2 )) 
  {
     alert("Please enter correct email ID")
   document.getElementById('email').focus();
     return false;
  }

var o=document.forms["myForm"]["password"].value;
if(o=="")
{
alert("Please Fill password Field");
document.getElementById('password').focus();
return false;
}
if(o.length<8){  
   alert("Password must be at least 8 characters long.");  
   document.getElementById('password').focus();
    return false;  
}

var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})"); 
  if(!strongRegex.test(document.myForm.log_pswd.value)) 
	  {
      alert("Error: password should contain atleast one uppercase,lowercase ,digit and special characters!");
      myForm.log_pswd.focus();
    return false;
     } 
   


</script>
</script>
<style>
body
{
<body background="regcustomer.jpg">
}


input[type=text],[type=date],[type=radio],[type=email],[type=password] ,select, textarea {
    width: 60%;
    padding: 12px;
    border: 2px solid #ccc;
    border-radius: 5px;
    resize: vertical;
}

h1
{
margin-left:120px;
color:white;
}
label {
    padding:12px,20px;
    display: inline-block;
color:white;
}

input[type=submit],[type=button] {
    
    background-color:green;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-left=200px;
    float: center;
}

input[type=submit]:hover {
    background-color: #45a049;
}
input[type=button]:hover {
    background-color: #45a049;
}
.container {
    border-radius:5px;
    background-image: url("regstaff.jpg");
    padding: 20px;
    margin-left:400px;
width:40%;
 
}

.col-25 {
    float: left;
    width: 25%;
    margin-top: 6px;
}

.col-75 {
    float: left;
    width: 75%;
    margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .col-25, .col-75, input[type=submit],input[type=button] {
        width: 100%;
        margin-top: 0;
    }
}
</style>
</head>
<body >


<div class="container">
<h1>Registration Form</h1>
 <form name="myForm" method="post" action="customerregister.php"


   onsubmit="return validateForm()" method="post">
    <div class="row">
      <div class="col-25">
        <label for="fname">First Name</label>
      </div>
      <div class="col-75">
   <input type="text" name="firstname" id="firstname" required="">
       
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="lname">Last Name</label>
      </div>
      <div class="col-75">
      <input type="text" name="lastname" id="lastname">
       
      </div>
    <div class="row">
      <div class="col-25">
        <label for="address">Address</label>
      </div>
      <div class="col-75">
        <textarea  name="adress" id="adress" placeholder="Address.."></textarea>
      </div>
    </div>





  <div class="row">
      <div class="col-25">
        <label for="city">City</label>
      </div>
      <div class="col-75">
   <input type="text" name="city" id="city">
       
      </div>
    </div>

  <div class="row">
      <div class="col-25">
        <label for="lanmark">lanmark</label>
      </div>
      <div class="col-75">
   <input type="text" name="lanmark" id="lanmark">
       
</div>
</div>



 <div class="row">
      <div class="col-25">
        <label for="housenumber">Housenumber</label>
      </div>
      <div class="col-75">
   <input type="text" name="houseno" id="houseno">
      </div>
    </div>
 
<div class="col-15">
        <label for="address">Gender</label>
      </div>
<input type="radio" name="sex" id ="gen" value="male">male  
  
 <input type="radio" name="sex" id ="gen" value="female">female</div>

<div class="row">
      <div class="col-25">
  <label for="dob">DOB</label>
      </div>
 <div class="col-75">
 <input type="date" name="DOB" id="DOB" placeholder="DOB..">
</div>

 <div class="row">
      <div class="col-25">
        <label for="phn">phone number</label>
      </div>
      <div class="col-75">
       <input type="text" name="phnno" id="phnno">
      
      </div>
<div class="row">
      <div class="col-25">
        <label for="email">Email</label>
      </div>
      <div class="col-75">
        <input type="email"  name="email" id="email" placeholder="Email id..">
      </div>
    </div>
<div class="row">
      <div class="col-25">
        <label for="dob">Password</label>
      </div>
      <div class="col-75">
 <input type="password" id="psw" name="password" id="password">
       
      </div>

<div class="row">
      <div class="col-25">
        <label for="DISTRICT">District</label>
      </div>
      <div class="col-75">
 
<table><tr><td><label for="DISTRICT"></td><td><select name="district" id="district">
<center><option>Tvm</option>
<option>Kollam</option>
<option>Pta</option>
<option>Alappuzha</option>
<option>Kottayam</option>
<option>Ekm</option>
<option>Idukki</option>
<option>Thrissur</option>
<option>Palakkad</option>
<option>Kozhikodu</option>
<option>Malappuram</option>
<option>Kannur</option>
<option>Wayanadu</option>
<option>Kazargodu</option>
</center></table>

</td></tr>
<tr><td></td><td><input type="submit" name="submit" id="submit" value="submit"></td></tr>
</center></table>
<div class="row">
     <div class="col-25">
 
 
    
  
</div>

</body>
 </form>
<?php
 include "connection.php";
 if(isset($_POST['submit']))
{
$fn=$_POST['firstname'];
$ln=$_POST['lastname'];
$ad=$_POST['adress'];
$ci=$_POST['city'];
$la=$_POST['lanmark'];
$hn=$_POST['houseno'];
$ge=$_POST['gender'];
$DOB=$_POST['DOB'];
$ph=$_POST['phnno'];
$email=$_POST['email'];
$pas=$_POST['password'];
$di=$_POST['district'];






$sql="Insert into org1(email,password,status,role) values('$email','$pas',0,'customer')";
$obj=new db();
$obj->execute($sql);
$sel="select loginid from org1 where email='$email' and password='$pas'";
$login=$obj->execute($sel);
//echo $login; error due to string
$strr=mysqli_fetch_array($login);
 //echo $strr[0];
//echo "success";
$lo=$strr[0];

//$pq="insert into customerregister(`firstname`,`lastname`,`adress`,`city`,`lanmark`,`houseno`,`gender`,`DOB`,`phnno`,`email`,`password`,`district`)values('$fn','$ln', '$ad','$ci','$la','$hn','$ge','$DOB','$ph','$email','$pas','district')";
$sqlll="Insert into customerregister(`firstname`,`lastname`,`adress`,`city`,`lanmark`,`houseno`,`gender`,`DOB`,`phnno`,`district`,loginid) values('$fn','$ln', '$ad','$ci','$la','$hn','$ge','$DOB','$ph','$di',$lo)";
$objj=new db();
$objj->execute($sqlll);
 echo "<script> alert('Success');
           window.location='ORG1.php'</script>";

}
 
  
  //echo "<script> ('Success');
          // window.location='Org1.php'</script>";

// header("location:ORG1.php");

?>


</body>
</html>
