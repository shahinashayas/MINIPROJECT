<!DOCTYPE html>
<html>
<head>
<script type="text/javascript" src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js" nonce="2C511FC4C1018F4196C3C77B1581CC04" charset="UTF-8"></script><style>
* {
    box-sizing: border-box;
}

.column {
    float: left;
    width: 33.33%;
    padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
    content: "";
    clear: both;
    display: table;
}
</style>
</head>
<body>
<body bgcolor="lavendar"background=".jpg">

<form action="PAYNOW1.php">

<h2>BABYCARE</h2>
<p><h3>Body cream</p><h3>
<h3>Himalaya</h3>
<table>
<fieldset>
<div class="row">
  <div class="column">
    <img src="i1.jpg" alt="Snow" style="width:100%">
  </div>
 <div class="column">
<h3>Bath and Body Work Japanese Cherry Blossom 3 Piece Set W New Super Smooth Body Lotion W Shea Butter and Coconut Oil 8 oz , Shower Gel 10 Oz, and Fine Fragra<p><h3>

<h3>This set includes a New Body lotion 24 hr Moisture She Butter & Coconut Oil softer than old style</h3>
<p><h3>Qua:200gm</p></h3>
<p><h3>Rate:200/-</p></h3>


 </div>
 <div class="row">
 <td>
<button type="submit">PAY NOW</button> </td>

</div>
</div>
</table>
</fieldset>
</form>
</body>
</html>
