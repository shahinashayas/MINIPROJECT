
<?php 
include("connection.php");
include("check_session.php");
?>

<html>
<head>
<style>
body {
  margin: 0;
  font-family: Times New Roman, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: right;
  color: #f2f2f2;
  text-align: center;
  padding: 8px 6px;
  text-decoration: none;
  font-size: 20px;
	
width:10%;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
h2 

  {
    color: tomato;
    text-align: center;
    
	margin-top:80px;
	margin-bottom:80px;

   }
h1{
	color:white;
}
.img{
	width:1800px;
	height:500px;
    }
.centered {
    position: absolute;
    top: 40%;
    left: 50%;
    transform: translate(-50%, -50%);
    }
.text{
	width:105%;
	height:50%;
	margin-left:200px;
	margin-top:100px;
	 column-count: 2;
      }
.footer {
  position:fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   height:8%;
   background-color: black;
   margin-top:100px;
}
ul{
margin:0px;
padding:0px;
list-style:none;
}
ul li{
float:left;
width:200px;
height:60px;
background-color:pink;
opacity:.9;
line-height:50px;
text-align:center;
font-size:20px;
margin-right:30px;
}
ul li a{
text-decoration:none;
}
ul li a:hover{
background-color-green;

}
ul li ul li
{
display:none;l
}
ul li:hover ul li{
display:block;
}

</style>
</head>
<body>

<ul>
 <li><a> CATEGORIES</a>
    <ul>

<li><a href="images1.php">Babycare</a></li>
<li><a>Bread & Bakery</a></li>
<li><a>Nuts & Dates</a></li>
<li><a>Stationary</a></li>
<li><a>Kitchen Items</a></li>
<li><a>Detergents & Cleaning</a></li>
<li><a>Sweets</a></li>
<li><a>Juices</a></li>
<li><a>Icecreams</a></li>
</li></ul>


</ul>
<ul>
<li><a href="feedback.html">FEED BACK</a></ul>
<ul><li><a href="img.php">NEW ITEMS</a></ul>
<ul><li><a href="logouts.php">LOGOUT</a></ul>

<ul><li><a href="changepasswords.php">CHANGE PASSWORD</a></ul>

  </div>
</div>

</div>
<div class="img">
<img src="home image sm.jpg" width="2000" height="800">
 <div class="centered"><h1><style="color:red;">ZELSONN</h1></div>

</div>

<div class="footer"></div>
</body>
</html>